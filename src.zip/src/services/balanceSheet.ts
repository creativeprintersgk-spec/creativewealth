import { getStoredGroups, getStoredLedgers, getStoredEntries, getStoredVouchers, getStoredPortfolios, getAssetName } from "../logic";

export async function getBalanceSheet(_startDate: string, endDate: string, accountId?: string) {

  // Always pass accountId to getStoredGroups/getStoredLedgers for account isolation.
  const groups  = getStoredGroups(accountId);
  const ledgers = getStoredLedgers(accountId);
  const entries = getStoredEntries();
  const vouchers = getStoredVouchers();

  // Walk up parent chain to find the root type of a group
  const getGroupType = (groupId: string): string => {
    let current: any = groups.find((g: any) => g.id === groupId);
    while (current) {
      if (current.type) return current.type;
      current = groups.find((g: any) => g.id === current.parent);
    }
    return "ASSET";
  };

  // Build voucher map for quick lookup
  const voucherMap: Record<string, any> = {};
  vouchers.forEach((v: any) => voucherMap[v.id] = v);

  // Filter portfolios if accountId is provided
  const allPortfolios = getStoredPortfolios();
  const portfolioIds = accountId
    ? allPortfolios.filter((p: any) => p.accountId === accountId).map((p: any) => p.id)
    : null;

  const allLedgers = getStoredLedgers();

  // Balance calculator iterating over all entries up to endDate
  const calcLedgerBal = (ledger: any, groupType: string): number => {
    let debit = 0;
    let credit = 0;
    entries.forEach((e: any) => {
      if (String(e.ledgerId) === String(ledger.id)) {
        const v = voucherMap[e.voucherId];
        const entryDate = e.date || v?.date;
        const entryAcid = e.accountId || v?.accountId;
        const entryPfid = v?.portfolioId;

        const isOpeningBalance = !entryDate || entryDate === '' || entryDate === 'undefined';
        if (!isOpeningBalance && entryDate > endDate) return;

        if (accountId) {
          const belongsToAccount =
            (entryAcid === accountId) ||
            (entryPfid && portfolioIds?.includes(entryPfid));
          if (!belongsToAccount) return;
        }

        debit  += e.debit  || 0;
        credit += e.credit || 0;
      }
    });
    return groupType === "ASSET" ? debit - credit : credit - debit;
  };

  const groupMap: Record<string, any> = {};
  groups.forEach((g: any) => {
    groupMap[g.id] = { ...g, balance: 0, children: [], ledgers: [] };
  });

  const seenLids = new Set<string>();
  const ledgersToInclude: any[] = [];

  // 1. Add standard account ledgers
  ledgers.forEach((l: any) => {
    seenLids.add(String(l.id));
    ledgersToInclude.push(l);
  });

  // 2. Add all asset/security ledgers
  entries.forEach((e: any) => {
    const v = voucherMap[e.voucherId];
    const entryDate = e.date || v?.date;
    const entryAcid = e.accountId || v?.accountId;
    const entryPfid = v?.portfolioId;

    const isOpeningBalance = !entryDate || entryDate === '' || entryDate === 'undefined';
    if (!isOpeningBalance && entryDate > endDate) return;

    const belongsToAccount = !accountId ||
      (entryAcid === accountId) ||
      (entryPfid && portfolioIds?.includes(entryPfid));

    if (belongsToAccount && !seenLids.has(String(e.ledgerId))) {
      seenLids.add(String(e.ledgerId));
      const l = allLedgers.find((x: any) => String(x.id) === String(e.ledgerId));
      if (l) {
        ledgersToInclude.push(l);
      } else {
        const lidNum = Number(e.ledgerId);
        const name = getAssetName(lidNum >= 100000 ? (lidNum >= 500000 ? lidNum - 500000 : (lidNum >= 100000 ? lidNum - 100000 : lidNum)) : lidNum) || `Asset ${e.ledgerId}`;
        ledgersToInclude.push({
          id: String(e.ledgerId),
          name,
          groupId: lidNum >= 100000 ? '50' : 'suspense_virtual',
          openingBalance: 0,
          openingType: 'DR',
          amid: lidNum >= 100000 ? lidNum : undefined,
          acid: accountId ? Number(accountId) : undefined
        });
      }
    }
  });

  // Attach ledgers to groupMap
  ledgersToInclude.forEach((l: any) => {
    let targetGroup = String(l.groupId);
    if (!groupMap[targetGroup]) {
      const gGlobal = groups.find((g: any) => String(g.id) === targetGroup);
      if (gGlobal) targetGroup = String(gGlobal.id);
      else if (Number(l.id) >= 100000) targetGroup = '50';
      else if (!accountId) targetGroup = 'suspense_virtual';
      else return;
    }

    const type = getGroupType(targetGroup);
    let bal = calcLedgerBal(l, type);

    const displayBalance = type === 'EXPENSE' ? Math.abs(bal) : bal;

    // Keep P&L Capital Gain ledgers and standard account ledgers visible for drilldown even if zero balance
    const isPnlOrSpecial = ['460', '465', '470', '475', '485', '490', '480', '180'].includes(String(l.id)) || Number(l.id) < 100000;
    if (Math.abs(bal) < 0.01 && !isPnlOrSpecial) return;

    if (groupMap[targetGroup]) {
      groupMap[targetGroup].ledgers.push({ ...l, balance: bal, displayBalance, groupType: type });
    }
  });

  // Build tree (parent-child hierarchy)
  const tree: any[] = [];
  Object.values(groupMap).forEach((g: any) => {
    if (g.parent && groupMap[g.parent]) {
      groupMap[g.parent].children.push(g);
    } else {
      tree.push(g);
    }
  });

  const calcGroupBalance = (group: any): number => {
    let bal = group.ledgers.reduce((s: number, l: any) => s + l.balance, 0);
    group.children.forEach((child: any) => { bal += calcGroupBalance(child); });
    group.balance = bal;
    return bal;
  };
  tree.forEach(g => calcGroupBalance(g));

  const assets      = tree.filter(g => getGroupType(g.id) === "ASSET");
  const liabilities = tree.filter(g => getGroupType(g.id) !== "ASSET");

  const totalAssets      = assets.reduce((s, g) => s + g.balance, 0);
  const totalLiabilities = liabilities.reduce((s, g) => s + g.balance, 0);

  return {
    assets,
    liabilities,
    totalAssets,
    totalLiabilities,
  };
}
